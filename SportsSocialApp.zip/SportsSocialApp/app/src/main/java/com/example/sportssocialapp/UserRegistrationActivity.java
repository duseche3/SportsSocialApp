package com.example.sportssocialapp;

import android.app.ActionBar;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.text.DateFormat;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserRegistrationActivity extends AppCompatActivity {
    private final static String TAG = "UserRegistrationActivity";

    Firebase ref;

    EditText dobText;
    DatePickerDialog dobDialog;
    DateFormat dateFormat;
    Button submit;
    ProgressDialog regProgressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        ActionBar actionBar = getActionBar();
        if (actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);


        dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dobText = (EditText) findViewById(R.id.userDob);

        Calendar calendar = Calendar.getInstance();
        dobDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                dobText.setText(dateFormat.format(newDate.getTime()));
            }

        },calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        dobText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                dobDialog.show();
                return false;
            }
        });


        ref = new Firebase(BuildConfig.FIREBASE_URL);
    }

    private boolean validate(){
        Boolean missing = false;
        Boolean emailInvalid = false;
        Boolean passwordInvalid = false;

        TextView nameErr = (TextView) findViewById(R.id.nameError);
        TextView emailErr = (TextView) findViewById(R.id.emailError);
        TextView passErr = (TextView) findViewById(R.id.passError);
        TextView confirmErr = (TextView) findViewById(R.id.confirmError);
        TextView dobErr = (TextView) findViewById(R.id.dobError);
        TextView genderErr = (TextView) findViewById(R.id.genderError);
        TextView errorMsg = (TextView) findViewById(R.id.errorMessage);

        nameErr.setVisibility(View.INVISIBLE);
        emailErr.setVisibility(View.INVISIBLE);
        passErr.setVisibility(View.INVISIBLE);
        confirmErr.setVisibility(View.INVISIBLE);
        dobErr.setVisibility(View.INVISIBLE);
        genderErr.setVisibility(View.INVISIBLE);
        errorMsg.setText("");


        // name error checking
        String name = ((EditText) findViewById(R.id.userName)).getText().toString().trim();
        if(name.equals("")){
            missing = true;
            nameErr.setVisibility(View.VISIBLE);
        }
        else
            nameErr.setVisibility(View.INVISIBLE);

        // email error checking
        String email = ((EditText) findViewById(R.id.userEmail)).getText().toString().trim().toLowerCase();
        if(!email.equals("")) {
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailErr.setVisibility(View.VISIBLE);
                emailInvalid = true;
            }
            else{
                emailErr.setVisibility(View.INVISIBLE);
            }
        }
        else{
            emailErr.setVisibility(View.VISIBLE);
            missing = true;
        }

        // password error checking
        String pass1 = ((EditText) findViewById(R.id.userPassword)).getText().toString();
        String pass2 = ((EditText) findViewById(R.id.userConfirmPassword)).getText().toString();

        if(pass1.equals("")){
            missing = true;
            passErr.setVisibility(View.VISIBLE);
        }

        if(pass2.equals("")){
            missing = true;
            confirmErr.setVisibility(View.VISIBLE);
        }

        if(!(pass1.equals(pass2))){
            passwordInvalid = true;
            confirmErr.setVisibility(View.VISIBLE);
        }


        // date of birth error checking
        String dob = ((EditText) findViewById(R.id.userDob)).getText().toString().trim();
        if(dob.equals("")){
            missing = true;
            dobErr.setVisibility(View.VISIBLE);
        }

        // gender error checking
        RadioGroup gender = (RadioGroup) findViewById(R.id.userGender);
        if(gender.getCheckedRadioButtonId() == -1){
            missing = true;
            genderErr.setVisibility(View.VISIBLE);
        }

        if(missing){
            errorMsg.setText("Missing fields!");
            return false;
        }
        else if(emailInvalid){
            errorMsg.setText("Invalid email entered!");
            return false;
        }
        else if(passwordInvalid){
            errorMsg.setText("Passwords do not match!");
            return false;
        }
        else
            return true;
    }

    public void onSubmit(View v) {
        makeRegProgressDialog();
        if (!validate()) {
            return;
        }

        final String name = ((EditText) findViewById(R.id.userName)).getText().toString().trim();
        final String email = ((EditText) findViewById(R.id.userEmail)).getText().toString().trim().toLowerCase();
        final String password = ((EditText) findViewById(R.id.userPassword)).getText().toString();
        final String dob = ((EditText) findViewById(R.id.userDob)).getText().toString().trim();
        final int gender = ((RadioGroup) findViewById(R.id.userGender)).getCheckedRadioButtonId();

        final CoordinatorLayout coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);

        ref.createUser(email, password, new Firebase.ValueResultHandler<Map<String, Object>>(){
            @Override
            public void onSuccess(Map<String, Object> result) {
                String uid = result.get("uid").toString();

                // Sets the user data for the uid created for the user
                Firebase userInfoRef = ref.child("users").child(uid);
                User user = new User(name, dob, gender, getSportsList());
                userInfoRef.setValue(user);
                Log.d("UserRegistration", "User created with uid --> " + uid);

                // Send result to login activity and automatically log in
                Intent data = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("email", email);
                bundle.putString("password", password);
                data.putExtras(bundle);

                if (getParent() == null)
                    setResult(RESULT_OK, data);
                else
                    UserRegistrationActivity.this.getParent().setResult(RESULT_OK, data);

                regProgressDialog.dismiss();
                finish();
            }

            @Override
            public void onError(FirebaseError firebaseError) {
                switch (firebaseError.getCode()) {
                    case FirebaseError.EMAIL_TAKEN:
                        Snackbar.make(coordinatorLayout, "That email is already in use", Snackbar.LENGTH_SHORT).show();
                        break;
                }
                regProgressDialog.dismiss();
            }
        });
    }

    private List<String> getSportsList() {
        ArrayList<String> sports = new ArrayList<>();

        CheckBox soccer = (CheckBox) findViewById(R.id.soccer);
        CheckBox football = (CheckBox) findViewById(R.id.football);
        CheckBox tennis = (CheckBox) findViewById(R.id.tennis);
        CheckBox golf = (CheckBox) findViewById(R.id.golf);
        CheckBox volleyball = (CheckBox) findViewById(R.id.volleyball);
        CheckBox baseball = (CheckBox) findViewById(R.id.baseball);
        CheckBox rugby = (CheckBox) findViewById(R.id.rugby);
        CheckBox basketball = (CheckBox) findViewById(R.id.basketball);
        CheckBox lacrosse = (CheckBox) findViewById(R.id.lacrosse);
        CheckBox racquetball = (CheckBox) findViewById(R.id.racquetball);

        try {
            if (soccer.isChecked())
                sports.add(soccer.getText().toString());
            if (football.isChecked())
                sports.add(football.getText().toString());
            if (tennis.isChecked())
                sports.add(tennis.getText().toString());
            if (golf.isChecked())
                sports.add(golf.getText().toString());
            if (volleyball.isChecked())
                sports.add(volleyball.getText().toString());
            if (baseball.isChecked())
                sports.add(baseball.getText().toString());
            if (rugby.isChecked())
                sports.add(rugby.getText().toString());
            if (basketball.isChecked())
                sports.add(basketball.getText().toString());
            if (lacrosse.isChecked())
                sports.add(lacrosse.getText().toString());
            if (racquetball.isChecked())
                sports.add(racquetball.getText().toString());
        } catch (NullPointerException e) {
            Log.e("UserRegistration", e.getMessage());
        }

        return sports;
    }

    private void makeRegProgressDialog() {
        regProgressDialog = new ProgressDialog(this);
        regProgressDialog.setMessage("Registering");
        regProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        regProgressDialog.show();
    }
}