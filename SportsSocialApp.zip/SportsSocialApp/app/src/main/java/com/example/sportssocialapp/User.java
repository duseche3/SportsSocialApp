package com.example.sportssocialapp;

import java.util.List;

public class User {
    public static User instance;

    private int gender;
    private String fullName;
    private String dob;
    private List<String> sports;

    public User() {}

    public User(String name, String dob, int gender) {
        this.fullName = name;
        this.dob = dob;
        this.gender = gender;
    }
    public User(String name, String dob, int gender, List<String> sports) {
        this(name, dob, gender);
        this.sports = sports;
    }

    public String getFullName() {
        return fullName;
    }
    public String getDob() {
        return dob;
    }
    public int getGender() {
        return gender;
    }
    public List<String> getSports() {
        return sports;
    }

    public boolean setFullName(String fullName) {
        this.fullName = fullName;
        return true;
    }
    public boolean setDob(String dob) {
        this.dob = dob;
        return true;
    }
    public boolean setGender(int gender) {
        this.gender = gender;
        return true;
    }
    public boolean setSports(List<String> sports) {
        this.sports = sports;
        return true;
    }
}
