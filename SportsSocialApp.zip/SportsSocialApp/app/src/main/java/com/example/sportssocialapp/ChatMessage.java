package com.example.sportssocialapp;

/**
 * Created by Gakis on 3/30/2016.
 */
public class ChatMessage {
     public final boolean left;
     public final String message;


    public ChatMessage(boolean left, String message) {
        super();
        this.left = left;
        this.message = message;
    }
}
