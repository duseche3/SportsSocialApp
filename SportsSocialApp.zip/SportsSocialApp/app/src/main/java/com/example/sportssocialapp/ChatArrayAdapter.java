package com.example.sportssocialapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gakis on 3/30/2016.
 */
public class ChatArrayAdapter extends ArrayAdapter<ChatMessage>{
    private TextView chattext;
    private List<ChatMessage> MessageList = new ArrayList<ChatMessage>();
    private LinearLayout layout;


    public ChatArrayAdapter(Context context, int textViewresourceId){
        super(context, textViewresourceId);
    }

    public void add(ChatMessage chatMessage) {
        MessageList.add(chatMessage);
        super.add(chatMessage);
    }

    public int getCount(){
        return this.MessageList.size();
    }

    public ChatMessage getItem(int index){

        return this.MessageList.get(index);
    }

    public View getView(int position, View ConvertView, ViewGroup parent){
        View v = ConvertView;

        if(v == null){
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.chat, parent, false);
        }
        layout = (LinearLayout) v.findViewById(R.id.Message1);
        ChatMessage messagobj = getItem(position);
        chattext = (TextView) v.findViewById(R.id.SingleMessage);
        chattext.setText(messagobj.message);

      //  chattext.setBackgroundResource(messagobj.left ? R.); //add bubbles to the sides

        layout.setGravity(messagobj.left ? Gravity.LEFT : Gravity.RIGHT);

        return v;
    }

    public Bitmap decodeToBitmap(byte[] decodeByte){
        return BitmapFactory.decodeByteArray(decodeByte, 0 , decodeByte.length);
    }
}
