package com.example.sportssocialapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

public class LoginActivity extends AppCompatActivity {
    private final static String TAG = "LoginActivity";

    Firebase ref;

    CoordinatorLayout coordinatorLayout;
    EditText emailInput;
    EditText passwordInput;
    Button submitButton;
    ProgressDialog authProgressDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (getActionBar() != null)
            getActionBar().setTitle(getResources().getString(R.string.title_activity_login));
        else if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(getResources().getString(R.string.title_activity_login));

        ref = new Firebase(BuildConfig.FIREBASE_URL);
        ref.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(AuthData authData) {
                if (authProgressDialog != null) {
                    authProgressDialog.dismiss();
                }
                if (authData != null) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    public void onSubmit(View v) {
        int errorCount = 0;

        emailInput = (EditText) findViewById(R.id.email);
        passwordInput = (EditText) findViewById(R.id.password);

        String email = emailInput.getText().toString().trim().toLowerCase();
        String password = passwordInput.getText().toString();

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Must be a valid email");
            errorCount++;
        } else {
            emailInput.setError(null);
        }

        if (errorCount > 0)
            return;

        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);

        Firebase.AuthResultHandler authResultHandler = new Firebase.AuthResultHandler() {
            @Override
            public void onAuthenticated(AuthData authData) {
            }

            @Override
            public void onAuthenticationError(FirebaseError firebaseError) {
                if (authProgressDialog != null) {
                    authProgressDialog.dismiss();
                }
                Snackbar.make(coordinatorLayout, "Error: " + firebaseError.getMessage(), Snackbar.LENGTH_SHORT).show();
            }
        };

        ref.authWithPassword(email, password, authResultHandler);
        makeAuthProgressDialog();


    }


    private static final int registrationRequestCode = 1;
    public void startRegistration(View v) {
        Intent intent = new Intent(this, UserRegistrationActivity.class);
        startActivityForResult(intent, registrationRequestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "Got result from " + requestCode);
        if (requestCode == registrationRequestCode)
            if (resultCode == RESULT_OK) {
                // We can assume that the login will be correct
                Bundle bundle = data.getExtras();
                ref.authWithPassword(bundle.getString("email"), bundle.getString("password"), null);
                makeAuthProgressDialog();
            }
    }

    private void makeAuthProgressDialog() {
        authProgressDialog = new ProgressDialog(this);
        authProgressDialog.setMessage("Logging In");
        authProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        authProgressDialog.show();
    }

}
